function CekUser(data_username, data_password) {
    let user = [
        ['admin', 'admin123'],
        ['santri', 'santri123'],
        ['aldi', 'aldial']
    ]

    for (user of user) {
        let u = user[0] 
        let p = user[1] 

        if (u == data_username && p == data_password) {
            window.location = "home.html"    
        }

    }

}

function Login() {
    
    let username = document.getElementById('username').value
    let password = document.getElementById('password').value

    if (username.length < 1 || password.length < 1) 
    {
        alert("Isi Username atau Password Terlebih Dahulu")
    }

    else if (password.length < 8) 
    {
        alert("Password Minimal 8 karakter")
    }
    else 
    {
       CekUser(username, password)
    }
}

document.getElementById('submit').addEventListener('click', Login)